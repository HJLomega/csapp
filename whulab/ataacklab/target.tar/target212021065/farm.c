/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned addval_179(unsigned x)
{
    return x + 2428995912U;
}

unsigned getval_116()
{
    return 2328072280U;
}

unsigned addval_486(unsigned x)
{
    return x + 2425378817U;
}

void setval_139(unsigned *p)
{
    *p = 3284633960U;
}

unsigned getval_325()
{
    return 2428995912U;
}

unsigned getval_395()
{
    return 2488822329U;
}

void setval_234(unsigned *p)
{
    *p = 3284634056U;
}

unsigned addval_192(unsigned x)
{
    return x + 3281279061U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned addval_435(unsigned x)
{
    return x + 3223375497U;
}

unsigned getval_309()
{
    return 3523789449U;
}

unsigned addval_293(unsigned x)
{
    return x + 3348156041U;
}

void setval_258(unsigned *p)
{
    *p = 3318206857U;
}

unsigned addval_124(unsigned x)
{
    return x + 3385118345U;
}

unsigned getval_426()
{
    return 3676360969U;
}

unsigned addval_288(unsigned x)
{
    return x + 2497743176U;
}

unsigned getval_201()
{
    return 3269495112U;
}

void setval_147(unsigned *p)
{
    *p = 2429454732U;
}

void setval_190(unsigned *p)
{
    *p = 3353381192U;
}

void setval_167(unsigned *p)
{
    *p = 3224949129U;
}

unsigned getval_199()
{
    return 3374371209U;
}

void setval_221(unsigned *p)
{
    *p = 3222851209U;
}

unsigned getval_346()
{
    return 3380920969U;
}

unsigned getval_152()
{
    return 3234123401U;
}

unsigned addval_407(unsigned x)
{
    return x + 3677930137U;
}

unsigned getval_284()
{
    return 3465075864U;
}

unsigned getval_298()
{
    return 2294792841U;
}

unsigned addval_178(unsigned x)
{
    return x + 3286272328U;
}

void setval_240(unsigned *p)
{
    *p = 683921805U;
}

unsigned addval_226(unsigned x)
{
    return x + 3232023177U;
}

unsigned getval_446()
{
    return 2425471625U;
}

void setval_383(unsigned *p)
{
    *p = 2495777196U;
}

void setval_136(unsigned *p)
{
    *p = 3683962505U;
}

unsigned getval_368()
{
    return 1053016745U;
}

unsigned getval_168()
{
    return 3674263945U;
}

unsigned getval_347()
{
    return 3286272328U;
}

unsigned addval_317(unsigned x)
{
    return x + 2430650696U;
}

unsigned addval_115(unsigned x)
{
    return x + 3285305666U;
}

unsigned getval_286()
{
    return 3224424841U;
}

unsigned getval_233()
{
    return 3252717896U;
}

unsigned getval_173()
{
    return 2497743176U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
